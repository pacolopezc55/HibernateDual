package repositorio;

import java.util.*;

import org.hibernate.*;

import es.aytos.HibernateDual.modelo.*;
import util.*;

public class RepositorioPersona {

	public static Integer crearPersona(final Persona persona) {
		final Session sesion = HibernateUtil.getSessionFactory().getCurrentSession();

		try {
			sesion.beginTransaction();
			final Integer personaBBDD = (Integer) sesion.save(persona);
			sesion.getTransaction().commit();
			return personaBBDD;

		} catch (Exception e) {
			System.out.println("Se ha producido un error construyendo la sesion");
			sesion.getTransaction().rollback();
			throw new RuntimeException(e);
		} finally {
			sesion.close();
		}

	}

	public static Persona getPersona(final String nombre) {
		try (Session sesion = HibernateUtil.getSessionFactory().getCurrentSession()) {
			sesion.beginTransaction();
			return (Persona) sesion.createQuery("from Persona where nombre = :nombre").setParameter("nombre", nombre)
					.uniqueResult();
		} catch (Exception e) {
			System.out.println("Se ha producido un error al consultar la persona");
			throw new RuntimeException();
		}

	}

	public static List<Persona> consultarPersonas() {
		try (Session sesion = HibernateUtil.getSessionFactory().getCurrentSession()) {
			sesion.beginTransaction();
			final List<Persona> resultados = sesion.createQuery("from Persona").list();
			return resultados;
		} catch (Exception e) {
			System.out.println("Se ha producido un error al consultar la persona");
			throw new RuntimeException();
		}

	}

}
