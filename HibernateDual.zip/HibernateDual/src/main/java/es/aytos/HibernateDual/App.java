package es.aytos.HibernateDual;

import repositorio.*;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {

		Pruebas.crearPersona();
		RepositorioPersona.getPersona("Paco");
	}
}
