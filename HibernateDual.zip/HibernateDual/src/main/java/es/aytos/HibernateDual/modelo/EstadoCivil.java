package es.aytos.HibernateDual.modelo;

public enum EstadoCivil {
	CASADO, SOLTERO, VIUDO;

}
