package es.aytos.HibernateDual;

import java.util.*;

import es.aytos.HibernateDual.modelo.*;
import repositorio.*;

public class Pruebas {

	public static void crearPersona() {
		Persona persona = new Persona();
		persona.setNombre("Paco");
		persona.setApellidos("Lopez Chaparro");
		persona.setFechaNacimiento(new Date());
		persona.setEstadoCivil(EstadoCivil.CASADO);
		persona.setNif("17281757H");
		RepositorioPersona.crearPersona(persona);
	}

	public static void main(String[] args) {
		RepositorioPersona.getPersona("Paco");

	}
}
